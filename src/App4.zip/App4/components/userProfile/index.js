import UserProfile from './userProfile';
export default UserProfile; 