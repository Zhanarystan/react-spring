import CardDetails from './cardDetails';
export default CardDetails;